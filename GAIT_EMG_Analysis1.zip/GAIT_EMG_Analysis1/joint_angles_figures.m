tree = load_mvnx('4km');
a = diff(tree.footContact(3).footContacts);

rhs = find(a==1)+1;
count_rhs= length(rhs);
number_of_right_cycles = count_rhs-1;

a = (diff(tree.footContact(1).footContacts));
lhs= find(a==1)+1;

count_lhs= length(lhs);
number_of_left_cycles = count_lhs-1;
%%left knee figure

lk= tree.jointData(20).jointAngle;
lkf=lk(:,3);
figure;plot(lkf);hold on;plot(lhs,lkf(lhs),'ro');title("left knee before normalization") 

%%left ankle figure
ra= tree.jointData(21).jointAngle;
laf=ra(:,3);
figure;plot(laf);hold on;plot(lhs,laf(lhs),'ro');title("left ankle before normalization")
 
%%left hip figure 
lh= tree.jointData(19).jointAngle;
lhf=lh(:,3);
figure;plot(lhf);hold on;plot(lhs,lhf(lhs),'ro');title("left hip before normalization")

%%right knee figure

rk= tree.jointData(16).jointAngle;
rkf=rk(:,3);
figure;plot(rkf);hold on;plot(rhs,rkf(rhs),'ro');title("right knee before normalization") 

%%right ankle figure
ra= tree.jointData(17).jointAngle;
raf=ra(:,3);
figure;plot(raf);hold on;plot(rhs,raf(rhs),'ro');title("right ankle before normalization")
 
%%right hip figure 
rh= tree.jointData(15).jointAngle;
rhf=rh(:,3);
figure;plot(rhf);hold on;plot(rhs,rhf(rhs),'ro');title("right hip before normalization")



%%normalizied right knee
figure;
hold on
for i= 1: number_of_left_cycles-1
    rkftemp=rkf(rhs(i):rhs(i+1));
    frame100=1:100;
    oldframe=1:length(rkftemp);
    normvec=linspace(1,length(oldframe),length(frame100));
    plot(spline(oldframe,rkftemp,normvec));title("right knee after normalization")
    
end

%%normalizied right ankle
figure;
hold on
for i= 1: number_of_left_cycles-1
    raftemp=raf(rhs(i):rhs(i+1));
    frame100=1:100;
    oldframe=1:length(raftemp);
    normvec=linspace(1,length(oldframe),length(frame100));
    plot(spline(oldframe,raftemp,normvec));title("right ankle after normalization")
    
end

%%normalizied right hip figure
 figure;
hold on
for i= 1: number_of_left_cycles-1
    rhftemp=rhf(rhs(i):rhs(i+1));
    frame100=1:100;
    oldframe=1:length(rhftemp);
    normvec=linspace(1,length(oldframe),length(frame100));
    plot(spline(oldframe,rhftemp,normvec));title("right hip after normalization")
   
end






%%normalizied left knee
figure;
hold on
for i= 1: number_of_left_cycles-1
    lkftemp=lkf(lhs(i):lhs(i+1));
    frame100=1:100;
    oldframe=1:length(lkftemp);
    normvec=linspace(1,length(oldframe),length(frame100));
    plot(spline(oldframe,lkftemp,normvec));title("left knee after normalization")
    
end

%%normalizied left ankle
figure;
hold on
for i= 1: number_of_left_cycles-1
    laftemp=laf(lhs(i):lhs(i+1));
    frame100=1:100;
    oldframe=1:length(laftemp);
    normvec=linspace(1,length(oldframe),length(frame100));
    plot(spline(oldframe,laftemp,normvec));title("left ankle after normalization")
    
end

%%normalizied left hip figure
 figure;
hold on
for i= 1: number_of_left_cycles-1
    lhftemp=lhf(lhs(i):lhs(i+1));
    frame100=1:100;
    oldframe=1:length(lhftemp);
    normvec=linspace(1,length(oldframe),length(frame100));
    plot(spline(oldframe,lhftemp,normvec));title("left hip after normalization")
   
end
