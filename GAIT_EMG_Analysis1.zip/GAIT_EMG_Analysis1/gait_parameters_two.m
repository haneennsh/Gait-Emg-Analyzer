tree = load_mvnx('4km');
fs = 60;

% identify initial contact and toe-off events
toe_dataR = diff(tree.footContact(4).footContacts);
heel_dataR = diff(tree.footContact(3).footContacts);
toe_dataL = diff(tree.footContact(2).footContacts);
heel_dataL = diff(tree.footContact(1).footContacts);


foot_dataR = zeros(size(heel_dataR));
foot_dataR(heel_dataR == 1) = 1;
foot_dataR(toe_dataR == -1) = -1;

foot_dataL = zeros(size(heel_dataL));
foot_dataL(heel_dataL == 1) = 1;
foot_dataL(toe_dataL == -1) = -1;

heelstrikeR_idx = find(heel_dataR==1) +1;
gait_durationR = abs(diff(heelstrikeR_idx)/fs);

heelstrikeL_idx = find(heel_dataL==1) +1;
gait_durationL = abs(diff(heelstrikeL_idx)/fs);


icR_idx = find(heel_dataR==1) +1;
toR_idx = find(toe_dataR==-1) +1;

icL_idx = find(heel_dataL==1) +1;
toL_idx = find(toe_dataL==-1) +1;

foot_strikesR = find(foot_dataR == 1)+1;
toe_offsR = find(foot_dataR == -1)+1;

foot_strikesL = find(foot_dataL == 1)+1;
toe_offsL = find(foot_dataL == -1)+1;



count_rhs= length(heelstrikeR_idx);
number_of_right_cycles = count_rhs-1;

count_lhs= length(heelstrikeL_idx);
number_of_left_cycles = count_lhs-1;

% discard the first toe-off event if it occurs before the first initial contact

if toL_idx(1) < icL_idx(1)
    toL_idx = toL_idx(2:end);
end

if length(toL_idx) < length(icL_idx)
    
    icL_idx_truncated = icL_idx(1:length(toL_idx));
    icL_idx = icL_idx_truncated;
else
    
    toL_idx_truncated = toL_idx(1:length(icL_idx));
    toL_idx = toL_idx_truncated;
end



% discard the first toe-off event if it occurs before the first initial contact
if toR_idx(1) < icR_idx(1)
    toR_idx = toR_idx(2:end);
end

if length(toR_idx) < length(icR_idx)
    
    icR_idx_truncated = icR_idx(1:length(toR_idx));
    icR_idx = icR_idx_truncated;
else
    
    toR_idx_truncated = toR_idx(1:length(icR_idx));
    toR_idx = toR_idx_truncated;
end






% calculate stance phase time
stance_phase_timeR = (toR_idx - icR_idx) / fs; % fs is the sampling rate of the signal
swing_phase_timeR = gait_durationR - stance_phase_timeR;

mean_valvuesR = [mean(gait_durationR),mean(stance_phase_timeR),mean(swing_phase_timeR)];


stance_phase_timeL = (toL_idx - icL_idx) / fs; % fs is the sampling rate of the signal
if length(gait_durationL) < length(stance_phase_timeL)
    
    stance_phase_timeL_truncated= stance_phase_timeL(1:length(gait_durationL));
    stance_phase_timeL = stance_phase_timeL_truncated;
else
    
    gait_durationL_truncated = gait_durationL(1:length(stance_phase_timeL));
    gait_durationL = gait_durationL_truncated;
end


swing_phase_timeL = gait_durationL - stance_phase_timeL;

mean_valvuesL = [mean(gait_durationL),mean(stance_phase_timeL),mean(swing_phase_timeL)];


if length(toe_offsR) < length(foot_strikesL)
    
    foot_strikesL_truncated = foot_strikesL(1:length(toe_offsR));
    foot_strikesL = foot_strikesL_truncated;
else
    
    toe_offsR_truncated = toe_offsR(1:length(foot_strikesL));
    toe_offsR = toe_offsR_truncated;
end

if length(toe_offsL) < length(foot_strikesR)
    
    foot_strikesR_truncated = foot_strikesR(1:length(toe_offsL));
    foot_strikesR = foot_strikesR_truncated;
else
    
    toe_offsL_truncated = toe_offsL(1:length(foot_strikesR));
    toe_offsL = toe_offsL_truncated;
end


DS1 = (toe_offsR-foot_strikesL)/fs;
DS2 = (toe_offsL-foot_strikesR)/fs;

if length(DS1) < length(DS2)
    
    DS2_truncated = DS2(1:length(DS1));
    DS2 = DS2_truncated;
else
    
    DS1_truncated = DS1(1:length(DS2));
    DS1 = DS1_truncated;
end
total_DS = DS1+DS2; 


DS = mean(total_DS);

SSTR = mean(swing_phase_timeL);

SSTL = mean(swing_phase_timeR);








