tree = load_mvnx('4km');
fs = 60;

toe_dataR = diff(tree.footContact(4).footContacts);
heel_dataR = diff(tree.footContact(3).footContacts);
toe_dataL = diff(tree.footContact(2).footContacts);
heel_dataL = diff(tree.footContact(1).footContacts);

heel_strikesR = find(heel_dataR == 1)+1;
toe_offsR = find(toe_dataR == -1)+1;

heel_strikesL = find(heel_dataL == 1)+1;
toe_offsL = find(toe_dataL == -1)+1;


positionL_data = tree.segmentData(22).position;
positionR_data = tree.segmentData(18).position;

StrideL_length_idx = positionL_data(heel_strikesL,:);
StrideR_length_idx = positionR_data(heel_strikesR,:);



StrideL_length = sqrt(diff(StrideL_length_idx(:,1)).^2+diff(StrideL_length_idx(:,2)).^2+diff(StrideL_length_idx(:,3)).^2) .* 100;
StrideR_length = sqrt(diff(StrideR_length_idx(:,1)).^2+diff(StrideR_length_idx(:,2)).^2+diff(StrideR_length_idx(:,3)).^2) .* 100;

average = [mean(StrideL_length),mean(StrideR_length)];








