tree = load_mvnx('4km');
fs = 60;
time = linspace(0,(3640/60),3640);
time = time(:);


% Identify foot strikes and toe-offs
toe_dataR = diff(tree.footContact(4).footContacts);
heel_dataR = diff(tree.footContact(3).footContacts);
toe_dataL = diff(tree.footContact(2).footContacts);
heel_dataL = diff(tree.footContact(1).footContacts);


heel_strikesR = find(heel_dataR == 1)+1;
toe_offsR = find(toe_dataR == -1)+1;

heel_strikesL = find(heel_dataL == 1)+1;
toe_offsL = find(toe_dataL == -1)+1;

right_hs_idx = time(heel_strikesR);
left_hs_idx = time(heel_strikesL);

number_steps = length(heel_strikesR) + length(heel_strikesL); 
total_time = time(end);

cadence = number_steps/total_time * 60; 

