tree = load_mvnx('6km');

position = tree.segmentData(22).position;
time = linspace(0,(3638/60),3638);
time = time(:);
 

 
 
  distance = sqrt((position(end,1)-position(1,1))^2 + (position(end,2)-position(1,2))^2  + (position(end,3)-position(1,3))^2 );
  total_time = time(end);
  speed_ms = distance/total_time;
 speed_kmhr = speed_ms * 3.6 ;
 
