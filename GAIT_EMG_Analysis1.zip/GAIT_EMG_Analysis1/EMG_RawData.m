
load("2kmEMG.mat");
TAR= Data(1,:);
y=TAR;
figure (1);
subplot(3,2,1)
plot(y);
title('Raw Emg tibialis anterior right leg ');
xlabel('Sample number');
ylabel('volts');


%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (1);
subplot(3,2,2)
plot(yd);
title('Emg TAR no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (1);
subplot(3,2,3)
plot(yr);
title('Emg TAR no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (1);
subplot(3,2,4)
plot(yl);
title('Emg TAR no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (1);
subplot(3,2,5)
plot(yn);
title('Emg TAR no bias');
xlabel('Sample number');
ylabel('x100 percentage');





 TAL= Data(2,:);
y=TAL;
figure (2);
subplot(3,2,1)
plot(y);
title('Raw Emg  tibialis anterior left ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (2);
subplot(3,2,2)
plot(yd);
title('Emg TAL no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (2);
subplot(3,2,3)
plot(yr);
title('Emg  TAL no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (2);
subplot(3,2,4)
plot(yl);
title('Emg  TAL no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (2);
subplot(3,2,5)
plot(yn);
title('Emg TAL no bias');
xlabel('Sample number');
ylabel('x100 percentage');





 Lateral_Gastro_R= Data(3,:);
y=Lateral_Gastro_R;
figure (3);
subplot(3,2,1)
plot(y);
title('Raw Emg lateral gastrocnemius right ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (3);
subplot(3,2,2)
plot(yd);
title('Emg LGS_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (3);
subplot(3,2,3)
plot(yr);
title('Emg LGS_R no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (3);
subplot(3,2,4)
plot(yl);
title('Emg LGS_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (3);
subplot(3,2,5)
plot(yn);
title('Emg LGS_R no bias');
xlabel('Sample number');
ylabel('x100 percentage');





 
 Lateral_Gastro_L= Data(4,:);
y=Lateral_Gastro_L;
figure (4);
subplot(3,2,1)
plot(y);
title('Raw Emg lateral gastrocnemius left ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (4);
subplot(3,2,2)
plot(yd);
title('Emg LGS_L no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (4);
subplot(3,2,3)
plot(yr);
title('Emg LGS_L no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (4);
subplot(3,2,4)
plot(yl);
title('Emg LGS_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
yn = yl/y_max;
figure (4);
subplot(3,2,5)
plot(yn);
title('Emg LGS_R no bias');
xlabel('Sample number');
ylabel('x100 percentage');




  
 Rectus_femoris_R= Data(5,:);
y=Rectus_femoris_R;
figure (5);
subplot(3,2,1)
plot(y);
title('Raw Emg Rectus femoris Right ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (5);
subplot(3,2,2)
plot(yd);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (5);
subplot(3,2,3)
plot(yr);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (5);
subplot(3,2,4)
plot(yl);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (5);
subplot(3,2,5)
plot(yn);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('x100 percentage');




 Rectus_femoris_L= Data(6,:);
y=Rectus_femoris_L;
figure (6);
subplot(3,2,1)
plot(y);
title('Raw Emg Rectus femoris Left ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (6);
subplot(3,2,2)
plot(yd);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (6);
subplot(3,2,3)
plot(yr);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (6);
subplot(3,2,4)
plot(yl);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (6);
subplot(3,2,5)
plot(yn);
title('Emg RF_R no bias');
xlabel('Sample number');
ylabel('x100 percentage');





 Vastus_Lateralis_R= Data(7,:);
y=Vastus_Lateralis_R;
figure (7);
subplot(3,2,1)
plot(y);
title('Raw Emg Vastus Lateralis R ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (7);
subplot(3,2,2)
plot(yd);
title('Emg VL_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (7);
subplot(3,2,3)
plot(yr);
title('Emg VL_R no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (7);
subplot(3,2,4)
plot(yl);
title('Emg VL_R no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (7);
subplot(3,2,5)
plot(yn);
title('Emg VL_R no bias');
xlabel('Sample number');
ylabel('x100 percentage');




 
 
 Vastus_Lateralis_L= Data(8,:);
y=Vastus_Lateralis_L;

figure (8);
subplot(3,2,1)
plot(y);
title('Raw Emg Vastus Lateralis Left ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (8);
subplot(3,2,2)
plot(yd);
title('Emg VL_L no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (8);
subplot(3,2,3)
plot(yr);
title('Emg VL_L no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (8);
subplot(3,2,4)
plot(yl);
title('Emg VL_L no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
%Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (8);
subplot(3,2,5)
plot(yn);
title('Emg VL_L no bias');
xlabel('Sample number');
ylabel('x100 percentage');




