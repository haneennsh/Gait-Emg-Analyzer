classdef ExampleApp < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        HighvoltageWarningLamp       matlab.ui.control.Lamp
        HighvoltageWarningLampLabel  matlab.ui.control.Label
        PhaseEditField               matlab.ui.control.NumericEditField
        Phase02Label                 matlab.ui.control.Label
        AmplitudeSlider              matlab.ui.control.Slider
        AmplitudeSliderLabel         matlab.ui.control.Label
        UIAxes                       matlab.ui.control.UIAxes
    end

    
    properties (Access = private)
        timer01;
        amplitude = 0;
        phase = 0;
        x = 0:0.01:5*pi;
    end
    
    methods (Access = private)
        
        function TimerCallback(app, ~, ~)
            
            % Plot the peaks function
            plot(app.UIAxes, app.x, app.amplitude.*sin(app.x+mod(app.phase, 2*pi)), 'LineWidth',2);
            hold(app.UIAxes,'on');
            plot(app.UIAxes, app.x, app.amplitude.*sin(app.x+mod(app.phase, 2*pi) - 2*pi/3), 'LineWidth',2);
            plot(app.UIAxes, app.x, app.amplitude.*sin(app.x+mod(app.phase, 2*pi) + 2*pi/3), 'LineWidth',2);
            hold(app.UIAxes,'off');
            legend(app.UIAxes, 'Va', 'Vb', 'Vc');
            grid(app.UIAxes, 'on');
            
            %Change lamp colors
            if app.amplitude < 325/3
                app.HighvoltageWarningLamp.Color = 'green';
            elseif app.amplitude > 325/3 && app.amplitude < 2*325/3
                    app.HighvoltageWarningLamp.Color = 'yellow';
            else 
                app.HighvoltageWarningLamp.Color = 'red';
            end
        end
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
          %Instanciate timer
          app.timer01 = timer('Period', 0.1,'ExecutionMode', ...
                              'fixedSpacing', 'TasksToExecute', Inf);
          app.timer01.TimerFcn = @app.TimerCallback;
          start(app.timer01);
          
          %Initialize plot axes 
          app.UIAxes.XLim = [-0 5*pi];
          app.UIAxes.YLim = [-350 350];
        end

        % Close request function: UIFigure
        function UIFigureCloseRequest(app, event)
            %Stop timer
            stop(app.timer01);
            delete(app.timer01);
            
            delete(app)
        end

        % Value changed function: PhaseEditField
        function PhaseEditFieldValueChanged(app, event)
            %Retrieves the phase value
            app.phase = app.PhaseEditField.Value;
        end

        % Value changing function: AmplitudeSlider
        function AmplitudeSliderValueChanging(app, event)
            %Update the amplitude
            app.UIAxes.XLim = [-0 5*pi];
            app.UIAxes.YLim = [-350 350];
            app.amplitude = event.Value;
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 517 455];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.CloseRequestFcn = createCallbackFcn(app, @UIFigureCloseRequest, true);

            % Create UIAxes
            app.UIAxes = uiaxes(app.UIFigure);
            title(app.UIAxes, '3 phase AC voltage')
            xlabel(app.UIAxes, 'X')
            ylabel(app.UIAxes, 'Y')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.Position = [21 84 477 347];

            % Create AmplitudeSliderLabel
            app.AmplitudeSliderLabel = uilabel(app.UIFigure);
            app.AmplitudeSliderLabel.HorizontalAlignment = 'right';
            app.AmplitudeSliderLabel.Position = [248 58 59 22];
            app.AmplitudeSliderLabel.Text = 'Amplitude';

            % Create AmplitudeSlider
            app.AmplitudeSlider = uislider(app.UIFigure);
            app.AmplitudeSlider.Limits = [0 325];
            app.AmplitudeSlider.ValueChangingFcn = createCallbackFcn(app, @AmplitudeSliderValueChanging, true);
            app.AmplitudeSlider.Position = [202 52 150 3];

            % Create Phase02Label
            app.Phase02Label = uilabel(app.UIFigure);
            app.Phase02Label.HorizontalAlignment = 'right';
            app.Phase02Label.Position = [59 53 79 22];
            app.Phase02Label.Text = 'Phase [0; 2π[';

            % Create PhaseEditField
            app.PhaseEditField = uieditfield(app.UIFigure, 'numeric');
            app.PhaseEditField.ValueChangedFcn = createCallbackFcn(app, @PhaseEditFieldValueChanged, true);
            app.PhaseEditField.Position = [71 32 62 22];

            % Create HighvoltageWarningLampLabel
            app.HighvoltageWarningLampLabel = uilabel(app.UIFigure);
            app.HighvoltageWarningLampLabel.HorizontalAlignment = 'center';
            app.HighvoltageWarningLampLabel.Position = [417 52 72 28];
            app.HighvoltageWarningLampLabel.Text = {'High voltage'; 'Warning'};

            % Create HighvoltageWarningLamp
            app.HighvoltageWarningLamp = uilamp(app.UIFigure);
            app.HighvoltageWarningLamp.Position = [442 26 20 20];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = ExampleApp

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end