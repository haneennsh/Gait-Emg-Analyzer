tree = load_mvnx('4km');
fs = 60;

toe_dataR = diff(tree.footContact(4).footContacts);
heel_dataR = diff(tree.footContact(3).footContacts);
toe_dataL = diff(tree.footContact(2).footContacts);
heel_dataL = diff(tree.footContact(1).footContacts);

heel_strikesR = find(heel_dataR == 1)+1;
toe_offsR = find(toe_dataR == -1)+1;

heel_strikesL = find(heel_dataL == 1)+1;
toe_offsL = find(toe_dataL == -1)+1;


positionL_data = tree.segmentData(22).position;
positionR_data = tree.segmentData(18).position;

StepL_length_idx = positionL_data(heel_strikesL);
StepR_length_idx = positionR_data(heel_strikesR);

if length(StepR_length_idx) < length(StepL_length_idx)
    
    StepL_length_idx_truncated = StepL_length_idx(1:length(StepR_length_idx));
    StepL_length_idx = StepL_length_idx_truncated;
    
else
    
    StepR_length_idx_truncated = StepR_length_idx(1:length(StepL_length_idx));
    StepR_length_idx = StepR_length_idx_truncated;
end



Step_length = sqrt((StepL_length_idx(:,1)- StepR_length_idx(:,1)).^2) *100;

step_lengthAvg = mean(Step_length);
