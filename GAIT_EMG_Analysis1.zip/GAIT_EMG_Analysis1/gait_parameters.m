% load data
tree = load_mvnx('2km');
fs = 60;

% identify initial contact and toe-off events
foot_data = diff(tree.footContact(2).footContacts);
heel_data = diff(tree.footContact(1).footContacts);

heelstrike_idx = find(heel_data==1) +1;
gait_duration = abs(diff(heelstrike_idx)/fs);

ic_idx = find(heel_data==1) +1;
to_idx = find(foot_data==-1) +1;

count_rhs= length(heelstrike_idx);
number_of_right_cycles = count_rhs-1;
% discard the first toe-off event if it occurs before the first initial contact
if to_idx(1) < ic_idx(1)
    to_idx = to_idx(2:end);
end

if length(to_idx) < length(ic_idx)
    
    ic_idx_truncated = ic_idx(1:length(to_idx));
    ic_idx = ic_idx_truncated;
else
    
    to_idx_truncated = to_idx(1:length(ic_idx));
    to_idx = to_idx_truncated;
end





% calculate stance phase time
stance_phase_time = (to_idx - ic_idx) / fs; % fs is the sampling rate of the signal
if length(stance_phase_time) < length(gait_duration)
    
    gait_duration_truncated = gait_duration(1:length(gait_duration));
    gait_duration = gait_duration_truncated;
else
    
    stance_phase_time_truncated = stance_phase_time(1:length(gait_duration));
    stance_phase_time= stance_phase_time_truncated;
end
swing_phase_time = gait_duration - stance_phase_time;

mean_valvues = [mean(gait_duration),mean(stance_phase_time),mean(swing_phase_time)];
