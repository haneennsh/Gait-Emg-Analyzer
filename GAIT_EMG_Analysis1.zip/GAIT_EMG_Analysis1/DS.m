% Load gait data into MATLAB
tree = load_mvnx('6km');
fs = 60;


% Identify foot strikes and toe-offs
toe_dataR = diff(tree.footContact(4).footContacts);
heel_dataR = diff(tree.footContact(3).footContacts);
toe_dataL = diff(tree.footContact(2).footContacts);
heel_dataL = diff(tree.footContact(1).footContacts);


foot_strikesR = find(heel_dataR == 1)+1;
toe_offsR = find(toe_dataR == -1)+1;

foot_strikesL = find(heel_dataL == 1)+1;
toe_offsL = find(toe_dataL == -1)+1;

if length(toe_offsR) < length(foot_strikesL)
    
    foot_strikesL_truncated = foot_strikesL(1:length(toe_offsR));
    foot_strikesL = foot_strikesL_truncated;
else
    
    toe_offsR_truncated = toe_offsR(1:length(foot_strikesL));
    toe_offsR = toe_offsR_truncated;
end

if length(toe_offsL) < length(foot_strikesR)
    
    foot_strikesR_truncated = foot_strikesR(1:length(toe_offsL));
    foot_strikesR = foot_strikesR_truncated;
else
    
    toe_offsL_truncated = toe_offsL(1:length(foot_strikesR));
    toe_offsL = toe_offsL_truncated;
end


DS1 = (toe_offsR-foot_strikesL)/fs;
DS2 = (toe_offsL-foot_strikesR)/fs;

if length(DS1) < length(DS2)
    
    DS2_truncated = DS2(1:length(toe_offsR));
    DS2 = DS2_truncated;
else
    
    DS1_truncated = DS1(1:length(foot_strikesL));
    DS1 = DS1_truncated;
end
total_DS = DS1+DS2; 

mean(total_DS)








