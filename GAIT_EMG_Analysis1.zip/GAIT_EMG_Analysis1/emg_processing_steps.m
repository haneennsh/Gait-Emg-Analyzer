%% 
% Step 1
% Read the raw EMG File
% clear all;
% close all;
% clc;
load("2kmEMG.mat");
LGS_R= Data(3,:);
y=LGS_R;
figure (1);
subplot(3,2,1)
plot(y);
title('Raw Emg LGS ');
xlabel('Sample number');
ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
figure (1);
subplot(3,2,2)
plot(yd);
title('Emg TA no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
figure (1);
subplot(3,2,3)
plot(yr);
title('Emg LGS no bias');
xlabel('Sample number');
ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
figure (1);
subplot(3,2,4)
plot(yl);
title('Emg LGS no bias');
xlabel('Sample number');
ylabel('volts');

%% Step 5
% Normalization of EMG Signal
y_max = max(yl);
yn = yl/y_max;
figure (1);
subplot(3,2,5)
plot(yn);
title('Emg LGS no bias');
xlabel('Sample number');
ylabel('x100 percentage');



