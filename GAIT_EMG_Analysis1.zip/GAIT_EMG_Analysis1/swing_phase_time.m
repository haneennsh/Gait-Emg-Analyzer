% load data
tree = load_mvnx('2km');
fs = 60;
% identify heel strikes and toe-off events
heel_data = diff(tree.footContact(3).footContacts);
toe_data = diff(tree.footContact(4).footContacts);

heelstrike_idx = find(heel_data==1) +1;
toeOff_idx = find(toe_data==-1) +1;


%
if length(heelstrike_idx) < length(toeOff_idx)
    
    toeOff_truncated = toeOff(1:length(heelstrike_idx));
    toeOff_idx= toeOff_truncated;
else
    
    heelstrike_idx_truncated = heelstrike_idx(1:length(toeOff_idx));
    heelstrike_idx = heelstrike_idx_truncated;
end

% calculate swing phase time

swing_time = abs((toeOff_idx - heelstrike_idx)/fs);

mean_swing_time = mean(swing_time);
stander_diavation_swing_time =std(swing_time);


