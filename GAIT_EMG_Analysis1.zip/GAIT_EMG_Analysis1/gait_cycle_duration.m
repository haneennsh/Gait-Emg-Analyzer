tree = load_mvnx('6km');
fs = 60;
% identify heel strikes and toe-off events
heel_data = diff(tree.footContact(3).footContacts);


heelstrike_idx = find(heel_data==1) +1;
gait_duration = abs(diff(heelstrike_idx)/fs);
mean(gait_duration)
