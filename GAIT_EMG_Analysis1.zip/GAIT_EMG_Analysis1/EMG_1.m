tree = load_mvnx('6km');
heel_data = diff(tree.footContact(3).footContacts);
time = linspace(0,(3640/60),3640);
time = time(:);

load("6kmEMG.mat");
TAR= Data(1,:);
y=TAR;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('TAR');
 xlabel('time');
 ylabel('volts');

 TAL= Data(2,:);
y=TAL;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('TAL');
 xlabel('time');
 ylabel('volts');

 Lateral_Gastro_R= Data(3,:);
y=Lateral_Gastro_R;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('Lateral_Gastro_R');
 xlabel('time');
 ylabel('volts');

 
 Lateral_Gastro_L= Data(4,:);
y=Lateral_Gastro_L;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('Lateral_Gastro_L');
 xlabel('time');
 ylabel('volts');

  
 Rectus_femoris_R= Data(5,:);
y=Rectus_femoris_R;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('Rectus_femoris_R');
 xlabel('time');
 ylabel('volts');

 Rectus_femoris_L= Data(6,:);
y=Rectus_femoris_L;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('Rectus_femoris_L');
 xlabel('time');
 ylabel('volts');


 Vastus_Lateralis_R= Data(7,:);
y=Vastus_Lateralis_R;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('Vastus_Lateralis_R');
 xlabel('time');
 ylabel('volts');
 
 
 Vastus_Lateralis_L= Data(8,:);
y=Vastus_Lateralis_L;
% figure (1);
% subplot(3,2,1)
% plot(y);
% title('Raw Emg LGS ');
% xlabel('Sample number');
% ylabel('volts');

%% Step 2
% Eliminate AC/DC Bias
yd = detrend(y);
% figure (1);
% subplot(3,2,2)
% plot(yd);
% title('Emg TA no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 3
% Signal Rectification
yr = abs(yd);
% figure (1);
% subplot(3,2,3)
% plot(yr);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');


%% Step 4
% Low-Pass Filter
[b,a] = butter (5, 20/2148/2, 'low'); % 1st element is the order of the filter 2nd element is cut of freq/smapl_freq/2, 3 rd element is type of filter
yl = filtfilt(b,a,yr);
% figure (1);
% subplot(3,2,4)
% plot(yl);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('volts');

%% Step 5
% Normalization of EMG Signal
% y_max = max(yl);
% yn = yl/y_max;
% figure (1);
% subplot(3,2,5)
% plot(yn);
% title('Emg LGS no bias');
% xlabel('Sample number');
% ylabel('x100 percentage');



heelstrike_idx = find(heel_data==1) +1;


t_hs_gait =  time(heelstrike_idx); % time in seconds

t_hs_emg = t_hs_gait * 2000; % time in samples

yl = yl(:);
emg_idx = ceil(t_hs_emg);
 m = yl(emg_idx); 
 figure;
 plot(m);
 title('Vastus_Lateralis_L');
 xlabel('time');
 ylabel('volts');


