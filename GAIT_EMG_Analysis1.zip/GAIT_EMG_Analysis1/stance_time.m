% load data
tree = load_mvnx('4km');
fs = 60;

% identify initial contact and toe-off events
gait_signal = diff(tree.footContact(4).footContacts);
heel_data = diff(tree.footContact(3).footContacts);

heelstrike_idx = find(heel_data==1) +1;
gait_duration = abs(diff(heelstrike_idx)/fs)+1;

ic_idx = find(gait_signal == 1) +1;
to_idx = find(gait_signal == -1) +1;

% discard the last toe-off event if it occurs after the last initial contact
if to_idx(end) > ic_idx(end)
    to_idx = to_idx(1:end-1);
end
% 
if length(to_idx) < length(ic_idx)
    
    ic_idx_truncated = ic_idx(1:length(to_idx));
    ic_idx = ic_idx_truncated;
else
    
    to_idx_truncated = to_idx(1:length(ic_idx));
    to_idx = to_idx_truncated;
end




% calculate stance phase time
stance_phase_time = abs((to_idx - ic_idx) / fs); % fs is the sampling rate of the signal

% % plot the gait signal with the identified events and the calculated stance phase time
% plot((1:length(gait_signal))/fs, gait_signal);
% hold on;
% plot(ic_idx/fs, gait_signal(ic_idx), 'o');
% plot(to_idx/fs, gait_signal(to_idx), 'x');
% xlabel('Time (s)');
% ylabel('Gait signal');
% legend('Gait signal', 'Initial contact', 'Toe-off');
% text(mean([ic_idx; to_idx])/fs, 0.5, ['Stance time = ' num2str(mean(stance_time)) ' s']);


