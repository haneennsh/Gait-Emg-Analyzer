classdef Gait_EMG_Analysis < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure             matlab.ui.Figure
        LoadGaitLabel        matlab.ui.control.Label
        LoadGaitButton       matlab.ui.control.Button
        LoadEMGLabel         matlab.ui.control.Label
        LoadEMGButton        matlab.ui.control.Button
        SegmentGaitLabel     matlab.ui.control.Label
        SegmentGaitButton    matlab.ui.control.Button
        AnalyzeEMGLabel      matlab.ui.control.Label
        AnalyzeEMGButton     matlab.ui.control.Button
        ResultsLabel         matlab.ui.control.Label
        ResultsTable         matlab.ui.control.Table
        FrequencyPlotLabel   matlab.ui.control.Label
        FrequencyPlot        matlab.ui.control.UIAxes
    end

    
    % App initialization and construction
    methods (Access = private)
        
        % Initializes UIFigure components
        function createComponents(app)
            
            % UIFigure creation
            app.UIFigure = uifigure;
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'Gait & EMG Analysis';
            app.UIFigure.Resize = 'off';
            app.UIFigure.Visible = 'on';
            
            % Load Gait label creation
            app.LoadGaitLabel = uilabel(app.UIFigure);
            app.LoadGaitLabel.HorizontalAlignment = 'right';
            app.LoadGaitLabel.Position = [40 425 70 22];
            app.LoadGaitLabel.Text = 'Load Gait';
            
            % Load Gait button creation
            app.LoadGaitButton = uibutton(app.UIFigure, 'push');
            app.LoadGaitButton.Position = [120 425 100 22];
            app.LoadGaitButton.Text = 'Browse...';
            
            % Load EMG label creation
            app.LoadEMGLabel = uilabel(app.UIFigure);
            app.LoadEMGLabel.HorizontalAlignment = 'right';
            app.LoadEMGLabel.Position = [40 375 70 22];
            app.LoadEMGLabel.Text = 'Load EMG';
            
            % Load EMG button creation
            app.LoadEMGButton = uibutton(app.UIFigure, 'push');
            app.LoadEMGButton.Position = [120 375 100 22];
            app.LoadEMGButton.Text = 'Browse...';
            
            % Segment Gait label creation
            app.SegmentGaitLabel = uilabel(app.UIFigure);
            app.SegmentGaitLabel.HorizontalAlignment = 'right';
            app.SegmentGaitLabel.Position = [40 325 70 22];
            app.SegmentGaitLabel.Text = 'Segment Gait';
            
            % Segment Gait button creation
            app.SegmentGaitButton = uibutton(app.UIFigure, 'push');
            app.SegmentGaitButton.Position = [120 325 100 22];
            app.SegmentGaitButton.Text = 'Segment';
            app.SegmentGaitButton.Enable = 'off';
            
            % Analyze EMG label creation
            app.AnalyzeEMGLabel = uilabel(app.UIFigure);
            app.AnalyzeEMGLabel.HorizontalAlignment = 'right';
            app.AnalyzeEMGLabel.Position = [40 275 70 22];
            app.AnalyzeEMGLabel.Text = 'Analyze EMG';
            
            % Analyze EMG button creation
            app.AnalyzeEMGButton = uibutton(app.UIFigure, 'push');
        end 
    end
end
            
