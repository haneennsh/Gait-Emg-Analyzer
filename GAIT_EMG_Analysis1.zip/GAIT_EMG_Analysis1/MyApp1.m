classdef MyApp1 < matlab.apps.AppBase
    
    % Properties
    properties (Access = public)
        UIFigure matlab.ui.Figure
        Dropdown matlab.ui.control.DropDown
        GraphAxes matlab.ui.control.UIAxes
        MinLabel          matlab.ui.control.Label
        MaxLabel          matlab.ui.control.Label
        MeanLabel matlab.ui.control.Label
      
        Tree struct
        LhsIndices
        RhsIndices
    end
 
    % Methods
    methods (Access = public)
        
        % App initialization
        function app = MyApp1
            % Load data
            app.Tree = load_mvnx('2km');
            app.LhsIndices = find(diff(app.Tree.footContact(1).footContacts) == 1) + 1;
            app.RhsIndices = find(diff(app.Tree.footContact(3).footContacts) == 1) + 1;
            
          
 % Create the App Designer figure
            app.UIFigure = uifigure;
            app.UIFigure.Position = [100, 100, 500, 400];
            app.UIFigure.Name = 'Gait';

       


            
            % Create the dropdown menu
            app.Dropdown = uidropdown(app.UIFigure);
            app.Dropdown.Items = {'Right Knee', 'Left Knee', 'Right Hip', 'Left Hip', 'Right Ankle', 'Left Ankle'};
            app.Dropdown.Position = [20, 300, 150, 30];
            app.Dropdown.ValueChangedFcn = createCallbackFcn(app, @dropdownValueChanged, true);
            
            % Create the graph axes
            app.GraphAxes = uiaxes(app.UIFigure);
            app.GraphAxes.Position = [100, 50, 300, 200];

              % Create MinLabel
            app.MinLabel = uilabel(app.UIFigure);
            app.MinLabel.Position = [400 120 100 22];
            app.MinLabel.Text = 'Minimum:';

            % Create MaxLabel
            app.MaxLabel = uilabel(app.UIFigure);
            app.MaxLabel.Position = [400 90 100 22];
            app.MaxLabel.Text = 'Maximum:';

               % Create MeanLabel
            app.MeanLabel = uilabel(app.UIFigure);
            app.MeanLabel.Position = [400, 150, 100, 22];
            app.MeanLabel.Text = 'Mean:';

             
    % Create the EMG button
    EMGButton = uibutton(app.UIFigure, 'push', 'Text', 'EMG', ...
        'Position', [20, 20, 100, 30], 'ButtonPushedFcn', @openEMGWindow);

    % EMG button callback to open a new window
    function openEMGWindow(~, ~)
        % Create a new window
        emgWindow = uifigure('Name', 'EMG Window');
        emgWindow.Position = [200, 200, 600, 400];
        
        % Add your desired components and functionality to the EMG window
          
    % Create UIAxes for plotting EMG signals
    emgAxes = uiaxes(emgWindow);
    emgAxes.Position = [50, 50, 500, 300];
    
    % Create Load EMG Data button
    loadButton = uibutton(emgWindow);
    loadButton.Position = [50, 360, 100, 30];
    loadButton.Text = 'Load EMG Data';
    loadButton.ButtonPushedFcn = @(~, ~) loadEMGData(emgAxes);
    

% Load EMG data from a file
Data = load('2kmEMG.mat');  % Replace '2kmEMG.mat' with the actual filename
Data = Data.Data;  % Replace 'Data' with the appropriate variable name

% Create the EMG button
emgButton = uibutton(emgWindow, 'push', 'Text', 'Muscles', ...
    'Position', [500, 20, 80, 30], 'ButtonPushedFcn', @openMusclesWindow);

% Function to open the Muscles window
function openMusclesWindow(~, ~)
    % Create the Muscles window
    musclesWindow = uifigure('Name', 'Muscles Window');
    musclesWindow.Position = [200, 200, 600, 400];

    % Define the muscle names and corresponding units
    muscleNames = {'tibialis anterior (Right)', 'tibialis anterior (Left)', 'Lateral Gastrocnemius (Right)', 'Lateral Gastrocnemius (Left)', 'Rectus Femoris (Right)', 'Rectus Femoris (Left)', 'Vastus Lateralis (Right)', 'Vastus Lateralis (Left)'};
    muscleUnits = {'Unit1', 'Unit2', 'Unit3', 'Unit4', 'Unit5', 'Unit6', 'Unit7', 'Unit8'};

    % Create the dropdown menu
    dropdown = uidropdown(musclesWindow, 'Items', muscleNames);
    dropdown.Position = [50, 300, 200, 30];

    % Create the axes for plotting
    axesPlot = uiaxes(musclesWindow);
    axesPlot.Position = [50, 50, 500, 200];

    % Initialize the graph with the first option
    plotGraph(dropdown.Value, axesPlot);

    % Add listener to the dropdown menu's 'ValueChanged' event
    addlistener(dropdown, 'ValueChanged', @(src, event) plotGraph(src.Value, axesPlot));

    % Function to plot the selected graph
    function plotGraph(selectedOption, axesPlot)
        % Get the index of the selected muscle
        muscleIndex = find(strcmp(selectedOption, muscleNames));

        % Get the corresponding data for the selected muscle
        y = Data(muscleIndex, :);

        % Perform the necessary data processing steps
        % Eliminate AC/DC Bias
        yd = detrend(y);

        % Signal Rectification
        yr = abs(yd);

        % Low-Pass Filter
        [b, a] = butter(5, 20/2148/2, 'low');
        yl = filtfilt(b, a, yr);

        % Clear existing plot
        cla(axesPlot);

        % Plot the graph
        plot(axesPlot, yl);
        xlabel(axesPlot, 'Time');
        ylabel(axesPlot, 'volts');
        title(axesPlot, selectedOption);
    end
end



    
    % Load EMG Data callback function
    function loadEMGData(axes)
        % Implement the logic to load EMG data from a file
         % Open a file dialog to select the EMG data file
    [filename, path] = uigetfile('*.mat', 'Select EMG Data File');
    if filename == 0
        % User canceled the file selection, do nothing
        return;
    end
    
    % Load the EMG data file
    data = matfile(fullfile(path, filename));
    
    % Extract the relevant variables from the loaded data
    TAR = data.Data(1,:);
    y = TAR;
    
    % Plot the EMG data on the specified axes
    plot(emgAxes, y);
    
    % Customize the plot properties as desired
    
    % Update any other relevant components or perform additional processing
    
    % Add your logic here to process the loaded EMG data
      
       
    end
    
   
    
    % Update Time Window callback function
    function updateTimeWindow(axes, value)
        % Implement the logic to update the time window of the plot on the axes
    end
    
  
    
    % Save EMG Data callback function
    function saveEMGData(axes)
        % Implement the logic to save the processed EMG data or analysis results
        % Use appropriate file formats, such as CSV or MAT files
    end
    
        % Show the EMG window
        emgWindow.Visible = 'on';
    end


   
            

           
        end
        
        
        % Value changed callback for the dropdown
        function dropdownValueChanged(app, ~, ~)
            % Get the selected option from the dropdown
            selectedOption = app.Dropdown.Value;
            
            % Clear the graph axes
            cla(app.GraphAxes);

            
            
            % Perform the corresponding action based on the selected option
            switch selectedOption
                case 'Right Knee'
                    % Code for Right Knee graph
                    number_of_left_cycles = length(app.LhsIndices) - 1;
                    rhs = app.RhsIndices;
                    rk = app.Tree.jointData(16).jointAngle;
                    rkf = rk(:,3);
                    
                    hold(app.GraphAxes, 'on');
                    for i = 1:number_of_left_cycles
                        rkftemp = rkf(rhs(i):rhs(i+1));
                        frame100 = 1:100;
                        oldframe = 1:length(rkftemp);
                        normvec = linspace(1, length(oldframe), length(frame100));
                        plot(app.GraphAxes, spline(oldframe, rkftemp, normvec));
                    end
                    title(app.GraphAxes, 'Right Knee after Normalization');

  % Calculate and display the minimum and maximum values
                   minVal = min(rkftemp);
                    maxVal = max(rkftemp);
                     meanVal = mean(rkftemp);
                  app.MinLabel.Text = ['Minimum: ', num2str(minVal)];
            app.MaxLabel.Text = ['Maximum: ', num2str(maxVal)];
            app.MeanLabel.Text = ['Mean: ', num2str(meanVal)];
                case 'Left Knee'
                    % Code for Left Knee graph
                     number_of_left_cycles = length(app.LhsIndices) - 1;
                    rhs = app.RhsIndices;
                    rk = app.Tree.jointData(20).jointAngle;
                    rkf = rk(:,3);
                    % Add your code for Left Knee graph here
                    hold(app.GraphAxes, 'on');
                    for i = 1:number_of_left_cycles
                        rkftemp = rkf(rhs(i):rhs(i+1));
                        frame100 = 1:100;
                        oldframe = 1:length(rkftemp);
                        normvec = linspace(1, length(oldframe), length(frame100));
                        plot(app.GraphAxes, spline(oldframe, rkftemp, normvec));
                    end
                    title(app.GraphAxes, 'Left Knee after Normalization');

                    % Calculate and display the minimum and maximum values
                   minVal = min(rkftemp);
                    maxVal = max(rkftemp);
                     meanVal = mean(rkftemp);
                  app.MinLabel.Text = ['Minimum: ', num2str(minVal)];
            app.MaxLabel.Text = ['Maximum: ', num2str(maxVal)];
             app.MeanLabel.Text = ['Mean: ', num2str(meanVal)];
                    
                case 'Right Hip'
                    % Code for Right Hip graph
                     number_of_left_cycles = length(app.LhsIndices) - 1;
                    rhs = app.RhsIndices;
                    rk = app.Tree.jointData(15).jointAngle;
                    rkf = rk(:,3);
                    % Add your code for Right Hip graph here
                     hold(app.GraphAxes, 'on');
                    for i = 1:number_of_left_cycles
                        rkftemp = rkf(rhs(i):rhs(i+1));
                        frame100 = 1:100;
                        oldframe = 1:length(rkftemp);
                        normvec = linspace(1, length(oldframe), length(frame100));
                        plot(app.GraphAxes, spline(oldframe, rkftemp, normvec));
                    end
                    title(app.GraphAxes, 'Right Hip after Normalization');

                    % Calculate and display the minimum and maximum values
                   minVal = min(rkftemp);
                    maxVal = max(rkftemp);
                     meanVal = mean(rkftemp);
                  app.MinLabel.Text = ['Minimum: ', num2str(minVal)];
            app.MaxLabel.Text = ['Maximum: ', num2str(maxVal)];
             app.MeanLabel.Text = ['Mean: ', num2str(meanVal)];
                    
                case 'Left Hip'
                    % Code for Left Hip graph
                     number_of_left_cycles = length(app.LhsIndices) - 1;
                    rhs = app.RhsIndices;
                    rk = app.Tree.jointData(19).jointAngle;
                    rkf = rk(:,3);
                    % Add your code for Left Hip graph here
                      hold(app.GraphAxes, 'on');
                    for i = 1:number_of_left_cycles
                        rkftemp = rkf(rhs(i):rhs(i+1));
                        frame100 = 1:100;
                        oldframe = 1:length(rkftemp);
                        normvec = linspace(1, length(oldframe), length(frame100));
                        plot(app.GraphAxes, spline(oldframe, rkftemp, normvec));
                    end
                    title(app.GraphAxes, 'Left Hip after Normalization');

                    % Calculate and display the minimum and maximum values
                   minVal = min(rkftemp);
                    maxVal = max(rkftemp);
                      meanVal = mean(rkftemp);
                  app.MinLabel.Text = ['Minimum: ', num2str(minVal)];
            app.MaxLabel.Text = ['Maximum: ', num2str(maxVal)];
             app.MeanLabel.Text = ['Mean: ', num2str(meanVal)];

                    
                case 'Right Ankle'
                    % Code for Right Ankle graph
                     number_of_left_cycles = length(app.LhsIndices) - 1;
                    rhs = app.RhsIndices;
                    rk = app.Tree.jointData(17).jointAngle;
                    rkf = rk(:,3);
                    % Add your code for Right Ankle graph here
                      hold(app.GraphAxes, 'on');
                    for i = 1:number_of_left_cycles
                        rkftemp = rkf(rhs(i):rhs(i+1));
                        frame100 = 1:100;
                        oldframe = 1:length(rkftemp);
                        normvec = linspace(1, length(oldframe), length(frame100));
                        plot(app.GraphAxes, spline(oldframe, rkftemp, normvec));
                    end
                    title(app.GraphAxes, 'Right Ankle after Normalization');

                    % Calculate and display the minimum and maximum values
                   minVal = min(rkftemp);
                    maxVal = max(rkftemp);
                     meanVal = mean(rkftemp);
                  app.MinLabel.Text = ['Minimum: ', num2str(minVal)];
            app.MaxLabel.Text = ['Maximum: ', num2str(maxVal)];
             app.MeanLabel.Text = ['Mean: ', num2str(meanVal)];

                    
                case 'Left Ankle'
                    % Code for Left Ankle graph
                     number_of_left_cycles = length(app.LhsIndices) - 1;
                    rhs = app.RhsIndices;
                    rk = app.Tree.jointData(21).jointAngle;
                    rkf = rk(:,3);
                    % Add your code for Left Ankle graph here
                      hold(app.GraphAxes, 'on');
                    for i = 1:number_of_left_cycles
                        rkftemp = rkf(rhs(i):rhs(i+1));
                        frame100 = 1:100;
                        oldframe = 1:length(rkftemp);
                        normvec = linspace(1, length(oldframe), length(frame100));
                        plot(app.GraphAxes, spline(oldframe, rkftemp, normvec));
                    end
                    title(app.GraphAxes, 'Left Ankle after Normalization');

                    % Calculate and display the minimum and maximum values
                   minVal = min(rkftemp);
                    maxVal = max(rkftemp);
                    meanVal = mean(rkftemp);
                  app.MinLabel.Text = ['Minimum: ', num2str(minVal)];
            app.MaxLabel.Text = ['Maximum: ', num2str(maxVal)];
             app.MeanLabel.Text = ['Mean: ', num2str(meanVal)];

                    
            end
        end
        
        % Run the app
        function run(app)
            % Show the UI
            app.UIFigure.Visible = 'on';
        end
        
    end
    
    % Main method to run the app
    methods (Static)
        function runMyApp
            app = MyApp;
            app.run;
        end
    end
    
end
