
% Load gait data
tree = load_mvnx('4km');
time = linspace(0,(3638/60),3638);
time = time(:);

% Identify heel strikes

data = diff(tree.footContact(3).footContacts);
data_2 = diff(tree.footContact(1).footContacts);

left_hs = find(data == 1)+1; 
right_hs = find(data_2 == 1)+1;

right_hs_idx = time(right_hs);
left_hs_idx = time(left_hs);

if length(right_hs_idx) < length(left_hs_idx)
    
    left_hs_truncated = left_hs_idx(1:length(right_hs_idx));
    left_hs_idx = left_hs_truncated;
else
    
    right_hs_truncated = right_hs_idx(1:length(left_hs_idx));
    right_hs_idx = right_hs_truncated;
end

step_times = abs(right_hs_idx - left_hs_idx);
step_timeAvg = mean(step_times);